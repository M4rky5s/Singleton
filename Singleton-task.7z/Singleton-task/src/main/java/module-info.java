module com.example.singletontask {
    requires javafx.controls;
    requires javafx.fxml;

    requires java.desktop;

    opens com.example.singletontask to javafx.fxml;
    exports com.example.singletontask;
}
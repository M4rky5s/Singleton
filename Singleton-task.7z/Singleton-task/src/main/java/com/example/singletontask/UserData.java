package com.example.singletontask;

public class UserData{
    private String shape;
    private String width;
    private String length;
    private UserDataSingleton userDataSingleton;

    public UserData(String shape, String width, String length){
        this.shape = shape;
        this.width = width;
        this.length = length;
        this.userDataSingleton = UserDataSingleton.getInstance();
        this.userDataSingleton.setUserData(this);
    }

    public String getShape(){
        return shape;
    }

    public String getWidth(){
        return width;
    }

    public String getLength(){
        return length;
    }

    @Override
    public String toString() {
        return "UserData{" +
                "forma='" + shape + '\'' +
                ", width='" + width + '\'' +
                ", length='" + length + '\'' +
                '}';
    }
}

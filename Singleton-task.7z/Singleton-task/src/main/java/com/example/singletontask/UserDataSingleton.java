package com.example.singletontask;

public class UserDataSingleton {
    private static UserDataSingleton instance;
    private UserData userData;

    private UserDataSingleton(){

    }

    public static UserDataSingleton getInstance(){
        if(instance == null){
            instance = new UserDataSingleton();
        }
        return instance;
    }

    public UserData getUserData(){
        return userData;
    }

    public void setUserData(UserData userData){
        this.userData = userData;
    }
}

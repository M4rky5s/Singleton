package com.example.singletontask;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class ResultWindowController extends HelloController {

    @FXML
    private Button closeButton;

    @FXML
    private Button calculateAreaButton;

    @FXML
    private Button calculatePerimeterButton;

    @FXML
    private Label resultLabel;

    @FXML
    private Button backButton;

    private UserData userData;
    private String shape;
    private Stage stage1;
    private Stage primaryStage;

    public void initialize() {
        postInitialize();
    }

    public void postInitialize(){
        if(resultLabel != null){
            if(userData != null){
                updateResultLabel();
            }
        }
        adjustStageSize();
    }

    public void setResult(String resultText){
        resultLabel.setText(resultText);
    }

    public void onCloseButtonClick() {
        Stage stage2 = (Stage) closeButton.getScene().getWindow();
        stage2.close();
    }

    public void onCalculateAreaButtonClick(){
        if(userData != null){
            String shape = userData.getShape();

            if("Trikampis".equals(shape)){
                double width = Double.parseDouble(userData.getWidth());
                double length = Double.parseDouble(userData.getLength());
                double area = 0.5 * width * length;

                String formattedArea = String.format("%.2f", area);
                setResult("Trikampio plotas: " + formattedArea);
            }else if("Kvadratas".equals(shape)){
                double side = Double.parseDouble(userData.getWidth());
                double area = side * side;

                String formattedArea = String.format("%.2f", area);
                setResult("Kvadrato plotas: " + formattedArea);
            }else{
                setResult("Pasirinkta netinkama forma");
            }
        }else{
            setResult("Klaida: Nera duomenu apie forma.");
        }

    }

    public void onCalculatePerimeterButtonClick(){

        if(userData != null) {
            String shape = userData.getShape();

            if ("Trikampis".equals(shape)) {
                double width = Double.parseDouble(userData.getWidth());
                double length = Double.parseDouble(userData.getLength());
                double hypotenuse = calculateHypotenuse(width, length);
                double perimeter = width + length + hypotenuse;

                String formattedPerimeter = String.format("%.2f", perimeter);

                setResult("Trikampio perimetras: " + formattedPerimeter);
            } else if("Kvadratas".equals(shape)){
                double side = Double.parseDouble(userData.getWidth());
                double perimeter = 4 * side;

                String formattedPerimeter = String.format("%.2f", perimeter);
                setResult("Kvadrato perimetras: " + formattedPerimeter);
            }else {
                setResult("Pasirinkta netinkama forma");
            }
        }else {
            setResult("Klaida: Nera duomenu apie forma.");
        }
    }

    private double calculateHypotenuse(double a, double b){
        return Math.sqrt(a * a + b * b);
    }

    public void setUserData(UserData userData){
        this.userData = userData;
        postInitialize();
    }

    public void setShape(String shape) {
        this.shape = shape;
    }

    private void updateResultLabel(){
        String shape = userData.getShape();
        String width = userData.getWidth();
        String length = userData.getLength();

        if(shape != null){
            resultLabel.setText("Forma: " + shape + "\nPlotis: " + width + "\nIlgis: " + length);
        }else {
            resultLabel.setText("Duomenys apie forma neperduoti");
        }
    }

    private void adjustStageSize(){
        if(resultLabel != null && resultLabel.getScene() != null && resultLabel.getScene().getWindow() != null) {
            Stage stage = (Stage) resultLabel.getScene().getWindow();
            stage.setMinWidth(400);
            stage.setMinHeight(200);
        }
    }

    public void setStage1(Stage stage1){
        this.stage1 = stage1;
    }

    @FXML
    public void onBackButtonClick() throws IOException{
        if(primaryStage != null){
            Stage stage2 = (Stage) backButton.getScene().getWindow();
            stage2.close();

            primaryStage.show();
        }
    }

    public void setPrimaryStage(Stage primaryStage){
        this.primaryStage = primaryStage;
    }

}

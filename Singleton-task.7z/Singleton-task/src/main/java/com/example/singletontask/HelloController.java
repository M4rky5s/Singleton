package com.example.singletontask;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

import java.io.IOException;

public class HelloController {
    @FXML
    private ChoiceBox<String> shapeChoiceBox;

    @FXML
    private TextField textField1;

    @FXML
    private TextField textField2;

    private Stage stage;

    public void setStage(Stage stage){
        this.stage = stage;
    }

    @FXML
    protected void onOkButtonClick() throws IOException {

        String shape = shapeChoiceBox.getValue();
        String width = textField1.getText();
        String length = textField2.getText();

        UserData userData = new UserData(shape, width, length);

        UserDataSingleton.getInstance().setUserData(userData);

        FXMLLoader resultLoader = new FXMLLoader(HelloApplication.class.getResource("ResultWindow.fxml"));
        VBox resultRoot = resultLoader.load();
        ResultWindowController resultController = resultLoader.getController();

        resultController.setUserData(UserDataSingleton.getInstance().getUserData());

        Stage resultStage = new Stage();
        resultStage.setScene(new Scene(resultRoot));
        resultStage.setTitle("Result Window");

        resultController.postInitialize();

        resultController.setPrimaryStage(stage);

        Stage stage2 = (Stage) shapeChoiceBox.getScene().getWindow();
        stage2.close();

        resultStage.show();
    }

    @FXML
    private void onBackButtonClick() throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        Stage stage1 = new Stage();
        stage1.setScene(new Scene(root));

        HelloController helloController = loader.getController();
        helloController.setStage(stage1);

        stage1.show();

        Stage stage2 = (Stage) shapeChoiceBox.getScene().getWindow();
        stage2.close();
    }
}